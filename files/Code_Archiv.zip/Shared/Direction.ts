namespace Platform_Game {
    export enum DIRECTION {
        LEFT, RIGHT
      }  
}